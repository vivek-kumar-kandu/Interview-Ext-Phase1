import sys
import json
import time
from pathlib import Path

# Add backend directory to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)
SESSION_ID = f"simulated-session-{int(time.time())}"

start_payload = {
    "sessionId": SESSION_ID,
    "candidate": {
        "member": {
            "id": "CAND-003",
            "name": "Emily Chen",
            "jobRole": "AI Engineer",
            "yearsExperience": 6,
            "education": "MS Artificial Intelligence",
            "status": "COMPLETED"
        },
        "missions": [
            {"day": 7, "title": "Embeddings Explained", "passed": True, "attempts": 1},
            {"day": 8, "title": "Vector Databases Overview", "passed": True, "attempts": 1},
            {"day": 10, "title": "Retrieval Engine", "passed": True, "attempts": 1},
            {"day": 12, "title": "Prompt Engineering Fundamentals", "passed": True, "attempts": 1},
            {"day": 13, "title": "Function Calling", "passed": True, "attempts": 1},
            {"day": 21, "title": "LangChain Agents", "passed": True, "attempts": 1},
            {"day": 22, "title": "Multi-Agent Orchestration", "passed": True, "attempts": 1},
            {"day": 28, "title": "Docker & Kubernetes Deployment", "passed": True, "attempts": 1}
        ],
        "signals": {"commitDays": 31, "missionsCompleted": 31, "missionsFirstTry": 30}
    }
}


def run_simulation():
    print("=" * 75)
    print(f"[STARTING FULL INTERVIEW SIMULATION] Session ID: {SESSION_ID}")
    print("=" * 75)

    # 1. Start Turn
    res = client.post("/api/interview", json=start_payload).json()
    print(f"\n[AI INTERVIEWER (Turn 1)]:\n{res['reply']}\n")

    answers = [
        "Embeddings map high-dimensional textual tokens into continuous vector spaces where semantic similarity translates to cosine proximity.",
        "Vector databases use indexing techniques like HNSW graphs or IVF to allow sub-millisecond approximate nearest neighbor searches.",
        "RAG retrieves relevant domain document chunks from a vector store and injects them into the LLM system prompt context to reduce hallucinations.",
        "Function calling parses predefined JSON schema parameters from the model output, enabling reliable integration with external backend tools and database APIs.",
        "LangChain agents use dynamic reasoning loops (like ReAct) to evaluate user input, choose tools from a registry, and iterate until solving the task.",
        "Multi-agent orchestration relies on state graph workflows (like LangGraph) or hierarchical supervisor patterns to divide complex goals among specialized sub-agents.",
        "Model Context Protocol (MCP) establishes standardized client-server interfaces for exposing local file systems and service context securely to LLM applications.",
        "Production deployment requires containerizing microservices with Docker, setting up horizontal pod autoscaling, monitoring latency, and tracking token costs."
    ]

    for turn_idx, answer in enumerate(answers, start=2):
        if res.get("done"):
            break

        print("-" * 75)
        print(f"[CANDIDATE RESPONSE (Turn {turn_idx - 1})]:\n{answer}\n")

        turn_payload = {
            "sessionId": SESSION_ID,
            "message": answer
        }

        res = client.post("/api/interview", json=turn_payload).json()

        if res.get("done"):
            print("=" * 75)
            print("[INTERVIEW COMPLETE - FINAL FEEDBACK RESPONSE RECEIVED]")
            print("=" * 75)
            print(f"\n[AI INTERVIEWER FINAL MSG]:\n{res['reply']}\n")

            feedback = res.get("feedback", {})
            print("STRUCTURED CANDIDATE FEEDBACK REPORT:")
            print(f"* Summary:   {feedback.get('summary')}")
            print(f"* Strengths: {json.dumps(feedback.get('strengths'), indent=2)}")
            print(f"* Gaps:      {json.dumps(feedback.get('gaps'), indent=2)}")
            print(f"* Next:      {json.dumps(feedback.get('next'), indent=2)}")
            print("=" * 75)
            break
        else:
            print(f"[AI INTERVIEWER (Turn {turn_idx})]:\n{res['reply']}\n")


if __name__ == "__main__":
    run_simulation()
