import logging
from typing import Tuple, Optional
from app.config import settings
from app.models.session import SessionState, TurnEvaluation
from app.schemas.interview import InterviewRequest, InterviewResponse, FeedbackSchema
from app.services.session_service import session_service
from app.services.candidate_analyzer import candidate_analyzer
from app.agents.question_generator import question_generator
from app.agents.followup_generator import followup_generator
from app.agents.evaluator import evaluator_engine
from app.agents.feedback_generator import feedback_generator

logger = logging.getLogger(__name__)


class InterviewOrchestrator:
    """
    Main state machine orchestrator for managing multi-turn AI candidate interviews.
    """
    async def process_turn(self, request: InterviewRequest) -> InterviewResponse:
        session_id = request.sessionId
        session = await session_service.get_session(session_id)

        # 1. Initialize session if new or profile passed
        if not session or request.candidate is not None:
            session = SessionState(
                session_id=session_id,
                candidate=request.candidate
            )
            # Plan curriculum days based on candidate signals
            if request.candidate:
                session.planned_days = candidate_analyzer.plan_interview_days(request.candidate)
            else:
                session.planned_days = [7, 10, 13, 21, 28]

            first_day = session.planned_days[0]
            session.current_day = first_day
            session.days_covered.append(first_day)

            # Generate first question
            question = await question_generator.generate_question(
                day=first_day,
                candidate=session.candidate,
                turn_index=1
            )

            session.current_question = question
            session.questions_asked = 1
            session.conversation_history.append({
                "role": "interviewer",
                "content": question
            })

            await session_service.save_session(session)

            candidate_name = session.candidate.member.name if session.candidate else "Candidate"
            welcome_msg = (
                f"Welcome {candidate_name}. Let's begin your technical interview.\n\n"
                f"Question 1 (Day {first_day}): {question}"
            )

            return InterviewResponse(
                reply=welcome_msg,
                done=False
            )

        # 2. Handle subsequent conversation turns
        user_message = request.message or ""
        session.conversation_history.append({
            "role": "candidate",
            "content": user_message
        })

        # Evaluate previous question turn
        if session.current_question and session.current_day:
            evaluation = await evaluator_engine.evaluate_turn(
                question=session.current_question,
                answer=user_message,
                day=session.current_day
            )
            session.evaluations.append(evaluation)

        # Check completion criteria:
        # Minimum 8 questions asked AND at least 4 distinct curriculum days covered
        distinct_days_count = len(set(session.days_covered))
        if session.questions_asked >= settings.MIN_QUESTIONS and distinct_days_count >= settings.MIN_CURRICULUM_DAYS:
            session.done = True
            feedback = await feedback_generator.generate_feedback(session)
            session.feedback = feedback
            await session_service.save_session(session)

            return InterviewResponse(
                reply="Thank you for your time. Your technical interview is now complete.",
                done=True,
                feedback=feedback
            )

        # 3. Determine next question & curriculum day
        next_turn_index = session.questions_asked + 1
        
        # Decide whether to ask follow-up or move to next planned day
        # E.g. every 2 questions change topic/day
        day_index = (next_turn_index - 1) // 2
        if day_index < len(session.planned_days):
            next_day = session.planned_days[day_index]
        else:
            next_day = session.planned_days[-1]

        if next_day not in session.days_covered:
            session.days_covered.append(next_day)

        session.current_day = next_day

        # Generate next question (main or follow-up)
        if next_turn_index % 2 == 0 and user_message:
            next_question = await followup_generator.generate_followup(
                question=session.current_question or "",
                answer=user_message,
                day=next_day
            )
        else:
            next_question = await question_generator.generate_question(
                day=next_day,
                candidate=session.candidate,
                turn_index=next_turn_index
            )

        session.current_question = next_question
        session.questions_asked = next_turn_index
        session.conversation_history.append({
            "role": "interviewer",
            "content": next_question
        })

        await session_service.save_session(session)

        reply_msg = f"Question {next_turn_index} (Day {next_day}): {next_question}"

        return InterviewResponse(
            reply=reply_msg,
            done=False
        )


interview_orchestrator = InterviewOrchestrator()
