import json
from typing import List
from app.config import settings
from app.models.session import SessionState, TurnEvaluation
from app.schemas.interview import FeedbackSchema


class FeedbackGenerator:
    """
    Synthesizes overall interview performance into structured feedback (summary, strengths, gaps, next).
    """
    async def generate_feedback(self, session: SessionState) -> FeedbackSchema:
        candidate_name = session.candidate.member.name if session.candidate else "Candidate"
        job_role = session.candidate.member.jobRole if session.candidate else "AI Software Engineer"
        years_exp = session.candidate.member.yearsExperience if session.candidate else 3

        all_strengths: List[str] = []
        all_gaps: List[str] = []
        
        for ev in session.evaluations:
            all_strengths.extend(ev.strengths_identified)
            all_gaps.extend(ev.gaps_identified)

        # Deduplicate while preserving order
        unique_strengths = list(dict.fromkeys(all_strengths))
        unique_gaps = list(dict.fromkeys(all_gaps))

        if settings.OPENAI_API_KEY:
            try:
                from langchain_openai import ChatOpenAI
                from langchain_core.messages import SystemMessage, HumanMessage
                from app.agents.prompts import SYSTEM_FEEDBACK_PROMPT

                llm = ChatOpenAI(
                    model=settings.OPENAI_MODEL,
                    api_key=settings.OPENAI_API_KEY,
                    temperature=0.3
                )

                eval_summary_lines = [
                    f"- Topic: {ev.topic} (Day {ev.day}), Score: {ev.score}/10, Feedback: {ev.feedback}"
                    for ev in session.evaluations
                ]

                sys_prompt = SYSTEM_FEEDBACK_PROMPT.format(
                    candidate_name=candidate_name,
                    job_role=job_role,
                    years_experience=years_exp,
                    questions_count=session.questions_asked,
                    days_count=len(session.days_covered),
                    evaluations_summary="\n".join(eval_summary_lines)
                )

                response = await llm.ainvoke([
                    SystemMessage(content=sys_prompt),
                    HumanMessage(content="Generate final JSON feedback strictly matching keys: summary, strengths, gaps, next.")
                ])

                content = response.content.strip()
                if content.startswith("```json"):
                    content = content.replace("```json", "").replace("```", "").strip()
                data = json.loads(content)

                return FeedbackSchema(
                    summary=data.get("summary", f"{candidate_name} completed a comprehensive technical interview for the {job_role} role."),
                    strengths=data.get("strengths", unique_strengths or ["Strong foundational domain knowledge"]),
                    gaps=data.get("gaps", unique_gaps or ["Can deepen practical optimization details"]),
                    next=data.get("next", ["Focus on advanced system architecture and edge-case handling."])
                )
            except Exception:
                pass

        # Robust deterministic fallback feedback
        days_str = ", ".join(map(str, session.days_covered)) if session.days_covered else "core modules"
        return FeedbackSchema(
            summary=(
                f"{candidate_name} demonstrated strong technical domain competency across "
                f"{session.questions_asked} technical questions covering curriculum days ({days_str})."
            ),
            strengths=unique_strengths[:4] if unique_strengths else [
                f"Solid grasp of core engineering topics in {job_role}",
                "Structured communication and problem-solving approach"
            ],
            gaps=unique_gaps[:3] if unique_gaps else [
                "Could provide deeper quantitative benchmarks in system design questions"
            ],
            next=[
                "Review advanced production deployment and monitoring practices",
                "Practice architectural trade-off evaluations under load"
            ]
        )


feedback_generator = FeedbackGenerator()
