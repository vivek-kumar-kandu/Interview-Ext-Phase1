from typing import Optional
from app.config import settings
from app.rag.retriever import curriculum_retriever
from app.services.curriculum_service import curriculum_service
from app.schemas.interview import CandidateProfile


class QuestionGenerator:
    """
    Generates tailored technical questions based on curriculum context and candidate background.
    """
    async def generate_question(
        self,
        day: int,
        candidate: Optional[CandidateProfile] = None,
        turn_index: int = 1
    ) -> str:
        day_info = curriculum_service.get_day_info(day)
        day_title = day_info.get("title", "Technical Concepts") if day_info else f"Day {day} Concepts"
        context = curriculum_retriever.get_day_context(day)

        if settings.OPENAI_API_KEY:
            try:
                from langchain_openai import ChatOpenAI
                from langchain_core.messages import SystemMessage, HumanMessage
                from app.agents.prompts import SYSTEM_INTERVIEWER_PROMPT

                llm = ChatOpenAI(
                    model=settings.OPENAI_MODEL,
                    api_key=settings.OPENAI_API_KEY,
                    temperature=0.7
                )

                job_role = candidate.member.jobRole if candidate else "Software Engineer"
                years_exp = candidate.member.yearsExperience if candidate else 3

                sys_prompt = SYSTEM_INTERVIEWER_PROMPT.format(
                    day=day,
                    day_title=day_title,
                    curriculum_context=context,
                    job_role=job_role,
                    years_experience=years_exp
                )

                response = await llm.ainvoke([
                    SystemMessage(content=sys_prompt),
                    HumanMessage(content=f"Generate Question #{turn_index} on {day_title}.")
                ])
                return response.content.strip()
            except Exception as e:
                pass

        # Deterministic fallback question format based on curriculum day
        tools = ", ".join(day_info.get("tools", ["core tools"])) if day_info else "core concepts"
        return f"Can you explain your experience and key design considerations when working with {day_title} (specifically using {tools})?"


question_generator = QuestionGenerator()
